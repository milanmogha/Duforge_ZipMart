/// <reference types="expo/types" />

// NOTE: This file should not be edited and should be committed with your changes.
