// Firebase phone-number OTP (matches the web portal's auth). Requires a dev
// build — phone auth does NOT work in Expo Go. google-services.json /
// GoogleService-Info.plist must be configured for com.zipmart.customer.
import auth, { FirebaseAuthTypes } from "@react-native-firebase/auth";

export type Confirmation = FirebaseAuthTypes.ConfirmationResult;

// phone must be E.164, e.g. "+919812345678"
export const sendPhoneOtp = (phone: string): Promise<Confirmation> =>
  auth().signInWithPhoneNumber(phone);

// Verify the SMS code and return a fresh Firebase ID token to exchange with
// the backend.
export const confirmOtp = async (
  confirmation: Confirmation,
  code: string
): Promise<string> => {
  const credential = await confirmation.confirm(code);
  if (!credential?.user) throw new Error("Invalid code. Please try again.");
  return credential.user.getIdToken();
};

export const signOutFirebase = () => auth().signOut();
